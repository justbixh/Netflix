package netFlix;

import java.util.Objects;

public class Movies implements Comparable{

	private String mname;//r
	private String duration;//r
	private int rating;//r w
	
	Movies(){
		System.out.println("Movie added successfully");
	}
	public Movies(String mname, String duration, int rating) {
		this();
		this.mname = mname;
		this.duration = duration;
		this.rating = rating;
	}
	public String getMname() {
		return mname;
	}
	
	public String getDuration() {
		return duration;
	}
	
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
		System.out.println("rating is uploaded");
	}
	
	public int compareTo(Object o) {
		Movies m=(Movies)o;
		return this.mname.compareTo(m.mname);
	}
	@Override
	public int hashCode() {
		return Objects.hash(duration, mname, rating);
	}
	@Override
	public boolean equals(Object o) {
		Movies m=(Movies)o;
		if(this.mname.equals(m.mname)&&this.duration.equals(m.duration)&&this.rating==m.rating) {
			return true;
		}
		else
			return false;
	}
	@Override
	public String toString() {
		return "Movies " + mname + "\tduration=" + duration + "\trating=" + rating;
	}
	
	
	
	
}
