package netFlix;

import java.util.Arrays;

public class NetFlix {

	User[] u=new User[10];
	Movies[] m=new Movies[10];
	{
		System.out.println("welcome to NetFlix");
	}
	public void creatAccount(User u1) {
		for (int i = 0; i < u.length; i++) {
			if(u[i]==null) {
				u[i]=u1;
				break;
			}
		}
	}
	public void login(String uname,String mailid) {
		for (int i = 0; i < u.length; i++) {
			User u1=u[i];
			if(u1!=null) {
				if(u1.getUname().equals(uname)&&u1.getMail_id().equals(mailid)) {
					System.out.println("Login successfully");
					break;
				}
				else
					System.out.println("invalid user name / mail id");
			}
			else
				System.out.println("user not found");
			
		}
	}
	
	public void addMovie(Movies m1) {
		for (int i = 0; i < m.length; i++) {
			if(m[i]==null) {
				m[i]=m1;
				break;
			}			
		}
	}
	public void movieList() {
		for (int i = 0; i < m.length; i++) {
			if(m[i]!=null) {
				System.out.println(m[i]);
			}
		}
	}
	
	public void sortMovies() {
		Arrays.sort(m);
	}
	
	public void filterDuration(String duration) {
		for (int i = 0; i < m.length; i++) {
			if(m[i]!=null) {
				if(m[i].getDuration().equals(duration)) {
					System.out.println(m[i]);
				}
			}
		}
	}
	
	public void filterRating(int rating) {
		for (int i = 0; i < m.length; i++) {
			if(m[i]!=null) {
				if(m[i].getRating()==(rating)) {
					System.out.println(m[i]);
				}
			}
		}
		
	}
	
	public void searchMovie(String mname) {
		for (int i = 0; i < m.length; i++) {
			if(m[i]!=null) {
				if(m[i].getMname().equals(mname)) {
					System.out.println(m[i]);
					break;
				}
				else
					System.out.println("movie not found");
			}
		}
	}
	public void removeMovie(String mname) {
		for (int i = 0; i < m.length; i++) {
			if(m[i]!=null) {
				if(m[i].getMname().equals(mname)) {
					m[i]=null;
					break;
				}
				else
					System.out.println("movie not found");
			}
		}
	}
	
	public void changeRating(String mname,int rating) {
		for (int i = 0; i < m.length; i++) {
			if(m[i]!=null) {
				if(m[i].getMname().equals(mname)) {
					m[i].setRating(rating);
					break;
				}
				else
					System.out.println("movie not found");
			}
		}
	}
	
	public void changeUname(String mailid,String name) {
		for (int i = 0; i < u.length; i++) {
			if(u[i]!=null) {
				if(u[i].getMail_id().equals(mailid)) {
					u[i].setUname(name);
					break;
				}
				else
					System.out.println("user not found");
			}
		}
	}
	public void changePhno(String name,long cno) {
		for (int i = 0; i < u.length; i++) {
			if(u[i]!=null) {
				if(u[i].getUname().equals(name)) {
					u[i].setPhno(cno);
					break;
				}
				else
					System.out.println("user not found");
			}
		}
	}
	
	public void userList() {
		for (int i = 0; i < u.length; i++) {
			if(u[i]!=null) {
				System.out.println(u[i]);
			}
		}
	}
	
	
}
