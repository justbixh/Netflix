package netFlix;

import java.util.Objects;

public class User {

	private String uname;//r w
	private String mail_id;//r
	private long phno;//r w
	
	User(){
		System.out.println("account created successfully");
	}
	User(String uname, String mail_id, long phno) {
		this();
		this.uname = uname;
		this.mail_id = mail_id;
		this.phno = phno;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
			this.uname = uname;
			System.out.println("user name is updated");
	}
	
	public String getMail_id() {
		return mail_id;
	}
	
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
			this.phno = phno;
			System.out.println("phone number is updated");
	}
	@Override
	public String toString() {
		return "User " + uname + "\t mail_id " + mail_id + "\tphno " + phno;
	}
	@Override
	public int hashCode() {
		return Objects.hash(mail_id, phno, uname);
	}
	@Override
	public boolean equals(Object o) {
		User u=(User)o;
		if(this.uname.equals(u.uname )&& this.mail_id.equals(u.mail_id)&&this.phno==u.phno) {
			return true;
		}
		else
			return false;
	}
	
	
	
	
	
	
}
