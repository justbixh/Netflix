package netFlix;

import java.util.Scanner;

public class NetFlixDriver {

	static Scanner s=new Scanner(System.in);
	public static void main(String[] args)throws Exception {
		NetFlix nf=new NetFlix();
		boolean repeat=true;
		do {
			Thread.sleep(3000);
			System.out.println("1.create account");
			System.out.println("2.login ");
			System.out.println("3.add movie");
			System.out.println("4.movie list");
			System.out.println("5.sort movie");
			System.out.println("6.filter movies");
			System.out.println("7.search movie");
			System.out.println("8.remove movie");
			System.out.println("9.change rating");
			System.out.println("10.change user name");
			System.out.println("11.change phone number");
			System.out.println("12.display user detail");
			System.out.println("13.logout");
			System.out.println("Enter your choice");
			int choice=s.nextInt();
			switch(choice) {
				case 1:
				{
					System.out.println("enter your name");
					String uname=s.next();
					System.out.println("enter your mail id");
					String umail=s.next();
					System.out.println("enter your contact number");
					long cno=s.nextLong();
					nf.creatAccount(new User(uname,umail,cno));
				}
				break;
				case 2:
				{
					System.out.println("enter your name");
					String uname=s.next();
					System.out.println("enter your mail id");
					String umail=s.next();
					nf.login(uname, umail);
				}
				break;
				case 3:
				{
					System.out.println("Enter the movie name");
					s.nextLine();
					String mname=s.nextLine();
					System.out.println("Enter the duration");
					String duration=s.nextLine();
					System.out.println("Enter the rating");
					int rating=s.nextInt();
					nf.addMovie(new Movies(mname,duration,rating));
				}
				break;
				case 4:
				{
					nf.movieList();
				}
				break;
				case 5:
				{
					nf.sortMovies();
				}
				break;
				case 6:
				{
					System.out.println(" based on 1.duration or 2.rating ");
					int c=s.nextInt();
					if(c==1) {
						System.out.println("enter the duration");
						s.nextLine();
						String dur=s.nextLine();
						nf.filterDuration(dur);
					}
					else if(c==2) {
						System.out.println("enter  the rating");
						int rating=s.nextInt();
						nf.filterRating(rating);
					}
				}
				break;
				case 7:
				{
					System.out.println("Enter the movie name");
					s.nextLine();
					String mname=s.nextLine();
					nf.searchMovie(mname);
				}
				break;
				case 8:
				{
					System.out.println("Enter the movie name");
					s.nextLine();
					String mname=s.nextLine();
					nf.removeMovie(mname);
				}
				break;
				case 9:
				{
					System.out.println("enter the movie name");
					String mname=s.nextLine();
					System.out.println("enter the rating");
					int rating=s.nextInt();
					nf.changeRating(mname, rating);
				}
				break;
				case 10:
				{
					System.out.println("Enter the mail id");
					s.nextLine();
					String mailid=s.nextLine();
					System.out.println("Enter the new name");
					String name=s.nextLine();
					nf.changeUname(mailid, name);
					
				}
				break;
				case 11:
				{
					System.out.println("Enter the user name ");
					String uname=s.nextLine();
					System.out.println("Enter the phone number");
					long cno=s.nextLong();
					nf.changePhno(uname, cno);
				}
				break;
				case 12:
				{
					nf.userList();
				}
				break;
				case 13:
				{
					System.out.println("thank you");
					repeat=false;
				}
				break;
				default:
				{
					System.out.println("Invalid option");
				}
			}
		}while(repeat);
		
		
	}
}
